//
//  SwiftUIView.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 24/04/24.
//

import SwiftUI



struct CuriosityView: View {
    var body: some View {
        
        VStack {
            Text("Dato del día").font(.title).fontWeight(.bold).foregroundColor(Color.white).multilineTextAlignment(.leading).padding()
            Text("¿Sabías que algunos alimentos tienen una huella de carbonomucho más alta que otros?").font(.title3).fontWeight(.bold).padding(1)
            Text("Por ejemplo, la carne de res y el queso tuienden a tener una huella más alta que las frutas y verduras, debido al impacto ambiental de la agricultura y la ganadería intensiva.").font(.caption).padding()
        }.background(customColor3).cornerRadius(10)
    }
}


struct CuriosityView_Previews: PreviewProvider {
    static var previews: some View {
        CuriosityView()
    }
}
