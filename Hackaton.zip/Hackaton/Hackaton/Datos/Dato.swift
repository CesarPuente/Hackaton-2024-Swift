//
//  PruebaView.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 24/04/24.
//

import Foundation
import SwiftUI



struct Dato {
    var titulo: String
    var info: String
    var imagen: Image
}
