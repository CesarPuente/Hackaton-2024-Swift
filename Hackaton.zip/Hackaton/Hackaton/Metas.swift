//
//  ContentView.swift
//  Progress
//
//  Created by Martin Alejandro Moreno Hernandez on 24/04/24.
//

import SwiftUI


struct Grafica: View {
    @State var progressValue: Float = 0.0
    
    var body: some View {
        VStack {
            ProgressBar(progress: self.$progressValue, color: Color(red:0.4509 , green:0.6705 ,blue: 0.9215))
                .frame(width: 170.0, height: 170.0)
                .padding(20.0).onAppear(){
                    self.progressValue = 0.60
                    
                
                }
        }
        
    }
}

struct ProgressBar: View {
    @Binding var progress: Float
    var color: Color = Color.green
    
    var body: some View {
        ZStack {
            Text("\n 12 Tn. de CO₂ \n\n")
                .foregroundStyle( Color(red:0.4509 , green:0.6705 ,blue: 0.9215))
                .font(.system(size: 20))
                .fontWeight(.heavy)
                .bold()
            Text("\n 0 Tn. de CO₂")
                .foregroundStyle(Color(red:0.7176 , green:0.8392 ,blue: 0.5411))
                .font(.system(size: 15))
                .fontWeight(.heavy)
                

            .overlay(
                
            Circle()
                .stroke(lineWidth: 160.0)
                .opacity(0.20)
                .foregroundColor(Color.gray))
            
  
            
            Circle()
                .trim(from: 0.0, to: CGFloat(min(self.progress, 1.0)))
                .stroke(style: StrokeStyle(lineWidth: 12.0, lineCap: .round, lineJoin: .round))
                .foregroundColor(color)
                .rotationEffect(Angle(degrees: 270))
                .animation(.easeInOut(duration: 2.0))
        }
        Spacer()
        Spacer()
    }
}



struct Grafica_Preview: PreviewProvider{
    static var previews: some View{
        Grafica()
    }
}


