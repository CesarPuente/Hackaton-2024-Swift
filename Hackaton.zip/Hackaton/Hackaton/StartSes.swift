//
//  StartSes.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 24/04/24.
//

import SwiftUI

struct HiddenBackButtonView<Content>: View where Content: View {
    var content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        content
            .navigationBarBackButtonHidden(true)
    }
}

struct StartSes: View {
    @State private var username = ""
    @State private var password = ""
    @State private var UNValidas = 0 //Credenciales de usuario no son válidas para inicio de sesión
    @State private var PNValidas = 0 //Credenciales de password no son válidas para inicio de sesión
    @State private var SigPantalla = false
    
    var body: some View {
        NavigationView{
            ZStack {
                Color(red: 0.9529, green: 0.9529, blue: 0.9294, opacity: 1.0) 
                    .ignoresSafeArea()
                Circle()
                    .scale(1.7)
                    .foregroundColor(.white.opacity(0.15))
                VStack {
                    //Image("Tierra2").resizable()
                        //.frame(width: 100, height: 100)
                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    TextField("Username", text: $username)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(customColor3)
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(UNValidas)).cornerRadius(4)
                    SecureField("Password", text: $password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(customColor3)
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(PNValidas)).cornerRadius(4)
                    Button("Login") {
                        AutenticarUser(username: username, password: password)
                    }
                    .foregroundColor(.white)
                    .frame(width: 300, height: 50)
                    .background(customColor)
                    .cornerRadius(10)
                    
                    Text("¿Olvidaste tu contraseña?")
                                            .foregroundColor(Color.blue)
                                            .bold()
                                        
                                        Text("Unirse ahora")
                                            .foregroundColor(Color.blue)
                                            .bold()
                    
                    NavigationLink(destination: HiddenBackButtonView {
                        ContentView()
                    }, isActive: $SigPantalla) {
                        EmptyView()
                    }
                    
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    func AutenticarUser(username: String, password: String) {
        if username.lowercased() == "bisontitos" {
            UNValidas = 0
            if password.lowercased() == "ganadores" {
                PNValidas = 0
                SigPantalla = true // Habilitar la siguiente pantalla si las credenciales son validas
            } else {
                PNValidas = 2
            }
        } else {
            UNValidas = 2
        }
    }
}

struct ContentView1: View {
    var username: String
    
    var body: some View {
        Text("Welcome, \(username)!")
    }
}

struct StartSes_Previews: PreviewProvider {
    static var previews: some View {
        StartSes()
    }
}
