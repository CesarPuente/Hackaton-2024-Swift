//
//  ContentView.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 23/04/24.
//

import SwiftUI

// estructura para calendario
struct CalendarView: View {
    @State private var selectedDate = Date()
    var body: some View{
        Text("Seleccione una fecha:").fontWeight(.bold).padding(20)
    DatePicker("", selection: $selectedDate, displayedComponents:.date)
        .datePickerStyle(GraphicalDatePickerStyle()).padding()
        Spacer()
    }
    
func formatterDate(date: Date) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "EEEE, d MMMM yyyy"
    return dateFormatter.string(from: date)
    }
        
}


let iconos = ["chart.pie", "pin", "plus", "flag", "gear"] // variable de apartados de navegación

//colores usados
let customColor = Color(red: 0.2313, green: 0.4705, blue: 0.3176, opacity: 1.0) // Verde Fuerte
let customColor2 = Color(red:0.3003, green:0.6823, blue:0.4470, opacity:1) // Verde medio
let customColor3 = Color(red: 0.8, green: 0.8941, blue: 0.8235, opacity: 1.0) // Verde claro
let customColor4 = Color(red: 0.9529, green: 0.9529, blue: 0.9294, opacity: 1.0) // Crema
let customColor5 = Color(red: 0.9294, green: 0.8627, blue: 0.5254, opacity: 1.0) //Amarillo claro
let customColor6 = Color(red: 0.7058, green: 0.8156, blue: 0.8549, opacity: 1.0)

struct ContentView: View {
    @State var IndexSeleccionado = 0
    var body: some View {
        
        VStack{
            Spacer()
            ZStack{
                
                switch IndexSeleccionado
                {
                case 0: // pantalla de gráficos
                    NavigationView
                    {
                        VStack
                        {
                            Image("Tierra1")
                        }
                        .navigationTitle("CarbonWallet")
                    }.background(customColor3)
                case 1: //pantalla de recomendaciones
                    NavigationView
                    {
                        ListView().navigationTitle("Recomendaciones")
                    }
                case 2:
                    NavigationView
                    {
                        VStack
                        {
                            CalendarView()
                        }
                        .navigationTitle("Calendario")
                    }
                case 3:
                    NavigationView
                    {
                        VStack
                        {
                            Grafica()
                        }
                        .navigationTitle("Metas")
                    }
                default:
                    NavigationView
                    {
                        VStack
                        {
                            ConfView()
                        }
                        .navigationTitle("Configuraciones")
                    }
                }
       
            }
            HStack
            {
                ForEach(0..<5, id: \.self){ numeros in
                  Spacer()
                  Button(action: {
                      self.IndexSeleccionado = numeros
                    
                }, label: {
                    if numeros == 2
                    {
                        Image(systemName: iconos[numeros]).frame(width: 60, height: 60).background(customColor).cornerRadius(30).font(.title).foregroundColor(.white)
                    }
                    else
                    {
                        Image(systemName: iconos[numeros]).font(.title).foregroundColor(.black)
                    }
                })
                    
                }
                Spacer()
            }
        }
        //.background(Color.red)
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
