//
//  HackatonApp.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 23/04/24.
//

import SwiftUI

@main
struct HackatonApp: App {
    var body: some Scene {
        WindowGroup {
            StartSes()
        }
    }
}
