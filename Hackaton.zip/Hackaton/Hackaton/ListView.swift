//
//  ListView.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 24/04/24.
//

import SwiftUI

struct Consejo {
    let title: String
    let info: String
    let imageName: String
}

let dato = [
    Consejo(title:"¿Sabías que algunos alimentos tienen una huella de carbonomucho más alta que otros?", info:"Por ejemplo, la carne de res y el queso tuienden a tener una huella más alta que las frutas y verduras, debido al impacto ambiental de la agricultura y la ganadería intensiva.", imageName: "exclamationmark.bubble")
]

let recomendaciones = [
    Consejo(title:"Reduce el consumo de energía", info:"Apaga las luces y desconecta equipos que no estés utilizando.", imageName: "light.min"),
    Consejo(title:"Usa el transporte público", info:"Usar el transporte público es una forma segura de reducir tu huella de carbono.", imageName: "tram.fill"),
    Consejo(title:"Disminuye el consumo de carne", info:"Consumir menos carne ayuda a reducir emisiones de gases de efecto invernadero.", imageName: "cart")
    
]

struct ListView: View {
    var body: some View {
        List {
            Section() {
                ForEach(dato, id: \.title) { device in
                    VStack(alignment: .center) {
                        Image(systemName: device.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 40, height: 40).padding(10)
                        Text(device.title)
                            .font(.headline)
                            .fontWeight(.bold)
                            .multilineTextAlignment(.center)
                        Spacer()
                        Text(device.info) .multilineTextAlignment(.center)
                        
                    }
                    
                }
            }
            Section(header: Text("Recomendaciones semanales")) {
                ForEach(recomendaciones, id: \.title) { device in
                    HStack {
                        Image(systemName: device.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 40, height: 40).padding(10)
                        VStack {
                            Text(device.title)
                                .fontWeight(.semibold).multilineTextAlignment(.leading).padding(1)
                            Text(device.info)
                        }
                        
                        
                    }
                }
            }
        }
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
