//
//  Configuracion.swift
//  Hackaton
//
//  Created by Nora Abigail de la Garza Arzola on 24/04/24.
//

import SwiftUI

struct Conf {
    let title: String
    let info: String
    let imageName: String
}


let Configs = [
    Conf(title:"Nombre del usuario", info:"Cuenta, informacion personal y pago", imageName: "person"),
    Conf(title:"Flores", info:"", imageName: "sun.max.fill"),
    Conf(title:"Vincular dispositivos", info:"", imageName: "personalhotspot"),
    Conf(title:"Solicitar estadisticas", info:"", imageName: "square.and.arrow.down"),
    Conf(title:"Idioma", info:"", imageName: "flag"),
    Conf(title:"Notificaciones", info:"", imageName: "bell"),
    Conf(title:"Permisos del dispositivo", info:"", imageName: "exclamationmark.icloud"),
    Conf(title:"Soporte técnico", info:"", imageName: "bubble.left.and.bubble.right"),
    Conf(title:"Acerca de", info:"", imageName: "info"),
    
    
]

struct ConfView: View {
    var body: some View {
        List {
            Section() {
                ForEach(dato, id: \.title) { device in
                    
                }
            }
            Section() {
                ForEach(Configs, id: \.title) { device in
                    HStack {
                        Image(systemName: device.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 40, height: 40).padding(10)
                        VStack {
                            Text(device.title)
                                .fontWeight(.semibold).multilineTextAlignment(.leading).padding(1)
                            Text(device.info)
                        }
                        
                        
                    }
                }
            }
        }
    }
}

struct ConfView_Previews: PreviewProvider {
    static var previews: some View {
        ConfView()
    }
}
